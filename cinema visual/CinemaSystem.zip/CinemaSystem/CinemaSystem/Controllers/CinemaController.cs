﻿using AutoMapper;
using CinemaSystem.Core;
using CinemaSystem.Core.Models;
using CinemaSystem.Dto.Cinemas;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CinemaSystem.Controllers
{
    public class CinemaController : CinemaSystemController
    {
        public CinemaController(IMapper mapper, CinemaSystemContext context) : base(mapper, context)
        {
        }

        [HttpGet("[action]")]
        public IActionResult GetAll(DateTime? startDate = null, DateTime? endDate = null)
        {
            IQueryable<Cinema> query = _context.Cinemas;
            if(startDate.HasValue)
            {
                query = query.Where(x => x.StartDate >= startDate);
            }
            if (endDate.HasValue)
            {
                query = query.Where(x => x.EndDate <= endDate);
            }

            var res = _mapper.Map<IEnumerable<CinemaCardDto>>(query);

            return Ok(res.ToList());

        }

        [HttpGet("[action]")]
        public IActionResult GetTodayCinemas()
        {
            var dateToday = DateTime.Today;
            var cinemas = _context.Seances.Include(x=>x.Cinema).Where(x=>x.Date.Year == dateToday.Year
            && x.Date.Month <= dateToday.Month
            //&& x.Date.Day <= dateToday.Day
            ).Select(x=>x.Cinema);

            var res = _mapper.Map<IEnumerable<CinemaCardDto>>(cinemas);

            return Ok(res.ToList());
        }

        [HttpGet("[action]")]
        public IActionResult Get(int cinemaId)
        {
            var cinema = _context.Cinemas.First(s => s.Id == cinemaId);
            var res = _mapper.Map<CinemaDto>(cinema);

            return Ok(res);
        }

        [HttpPost("[action]")]
        public IActionResult Create(CreateCinemaDto input)
        {
            var cinema = _mapper.Map<Cinema>(input);
            _context.Cinemas.Add(cinema);
            _context.SaveChanges();
            return Ok("фильм добавлен");
        }

        [HttpPost("[action]")]
        public IActionResult Delete(int id)
        {
            var cinema = _context.Cinemas.Find(id);
            _context.Cinemas.Remove(cinema);
            _context.SaveChanges();
            return Ok("фильм удален");

        }

        [HttpPost("[action]")]
        public IActionResult Update(CinemaDto input)
        {
            var cinema = _mapper.Map<Cinema>(input);
            _context.Cinemas.Update(cinema);
            _context.SaveChanges();
            return Ok("фильм обновлен");

        }
    }
}
