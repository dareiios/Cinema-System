﻿using AutoMapper;
using CinemaSystem.Core;
using CinemaSystem.Core.Models;
using CinemaSystem.Dto.Seances;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CinemaSystem.Controllers
{ 
    public class SeanceController : CinemaSystemController
    {
        public SeanceController(IMapper mapper, CinemaSystemContext context) : base(mapper, context)
        {
        }

        [HttpGet("[action]")]
        public IActionResult GetAll(int cinemaId)
        {
           var seances = _context.Seances.Include(x=>x.Cinema).Where(s => s.CinemaId == cinemaId).ToList();
            foreach(var seance in seances)
            {
                var tickets = _context.Tickets
                .Include(x => x.Seat)
                .ThenInclude(x => x.SeatType)
                .Where(x => x.SeanceId == seance.Id)
                .AsNoTracking()
                .ToList()
                .OrderBy(x => x.Seat.RowNumber)
                .ThenBy(x => x.Seat.Number);

                if (tickets.Any(x => x.Seat.SeatType.Name == "Standart"))
                {
                    seance.Price = tickets.First(x => x.Seat.SeatType.Name == "Standart").Price;
                }
                else
                {
                    seance.Price = tickets.First(x => x.Seat.SeatType.Name == "VIP").Price;

                }
            }
            return Ok(seances);
        }

        [HttpGet("[action]")]
        public IActionResult Get(int seanceId)
        {
            var seance = _context.Seances
                .Include(x => x.Cinema)
                .Include(x=>x.Hall)
                .AsNoTracking()
                .First(s => s.Id == seanceId);
            var tickets = _context.Tickets
                .Include(x => x.Seat)
                .ThenInclude(x => x.SeatType)
                .Where(x => x.SeanceId == seance.Id)
                .AsNoTracking()
                .ToList()
                .OrderBy(x=>x.Seat.RowNumber)
                .ThenBy(x=>x.Seat.Number);
            seance.Tickets = tickets.ToList();
            
            return Ok(seance);
        }

        [HttpPost("[action]")]
        public IActionResult Create(CreateSeanceDto input)
        {
            var seance = _mapper.Map<Seance>(input);
            _context.Seances.Add(seance);
            _context.SaveChanges();

            var seats = _context.Seats.Include(x => x.SeatType).Where(x => x.HallId == seance.HallId);
            foreach(var seat in seats)
            {
                _context.Tickets.Add(new Ticket
                {
                    CreationDate = DateTime.Now,
                    Price = seance.Price + seat.SeatType.Price,
                    SeatId = seat.Id,
                    SeanceId = seance.Id
                });
            }
            _context.SaveChanges();
            return Ok();
        }

        [HttpDelete("[action]")]
        public IActionResult Delete(int id)
        {
            var seance = _context.Seances.Find(id);
            _context.Seances.Remove(seance);
            _context.SaveChanges();
            return Ok();
        }

        [HttpPost("[action]")]
        public IActionResult Update(CreateSeanceDto input)
        {
            var seance = _mapper.Map<Seance>(input);
            _context.Seances.Update(seance);
            _context.SaveChanges();
            return Ok();
        }


        
    }
}
