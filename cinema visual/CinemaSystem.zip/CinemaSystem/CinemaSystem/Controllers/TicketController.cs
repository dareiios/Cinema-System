﻿using AutoMapper;
using CinemaSystem.Core;
using CinemaSystem.Core.Models;
using CinemaSystem.Dto.Tickets;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace CinemaSystem.Controllers
{
    public class TicketController : CinemaSystemController
    {
        public TicketController(IMapper mapper, CinemaSystemContext context) : base(mapper, context)
        {
        }

        [HttpGet("[action]")]
        public IActionResult GelAll(int seanceId)
        {
           var tickets = _context.Tickets.Where(x => x.SeanceId == seanceId);
           return Ok(_mapper.Map<IEnumerable<TicketDto>>(tickets));
        }

        [HttpPost("[action]")]
        public IActionResult Update(TicketDto input)
        {
            var ticket =_mapper.Map<Ticket>(input);
            _context.Tickets.Update(ticket);
            _context.SaveChanges();
            return Ok();
        }

        [HttpDelete("[action]")]
        public IActionResult Delete(int id)
        {
            var ticket = _context.Tickets.Find(id);
            _context.Tickets.Remove(ticket);
            _context.SaveChanges();
            return Ok();
        }

        [HttpPost("[action]")]
        public IActionResult Buy(BuyTicketDto input)
        {

            if (input.TicketIds == null || !input.TicketIds.Any())
            {
                return BadRequest();
            }
            

            var tickets = _context.Tickets.Where(x => input.TicketIds.Contains(x.Id)).ToList();

            if (tickets.Select(x => x.SeanceId).Distinct().Count()>1)
            {
                return BadRequest("Can not order tickets from many seanses");
            }

            var seance = _context.Seances.Include(x => x.Cinema).First(x => x.Id == tickets.First().SeanceId); 

            var from = new MailAddress("dareiiiios@yandex.ru", "Kinomax");
            var to = new MailAddress(input.Email);
            var message = new MailMessage(from, to);
            message.Subject = $"Покупка билетов на фильм {seance.Cinema.Name}";
            message.Body = $"Вы купили {tickets.Count} билетов на сеанс {seance.Cinema.Name} : \n";
            message.Body += $"Время сеанса: {seance.Date}\n";
            message.Body += $"Длительность рекламного блока: {seance.PromoDuration}\n";

            var i = 1;
            foreach (var ticket in tickets)
            {
                var seat = _context.Seats.First(x => x.Id == ticket.SeatId);
                message.Body += $"Билет {i++} : ряд {seat.RowNumber} место {seat.Number} цена: {ticket.Price}\n";
            }
            try
            {
                using var client = new SmtpClient("smtp.yandex.ru", 587);
                client.Credentials = new NetworkCredential("dareiiiios@yandex.ru", "xycitweqxbtmtngi");
                client.EnableSsl = true;
                client.Send(message);
                foreach(var ticketId in tickets.Select(x=>x.Id))
                {
                    var ticket = _context.Tickets.Find(ticketId);
                    ticket.Status = TicketStatus.Sold;
                    _context.Tickets.Update(ticket);
                    _context.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                
            }
            return (Ok());
        }
    }
}
